package com.amdocs.property.exception;

public class PropertyNotFoundException  {
	public PropertyNotFoundException() {
		super();
		System.out.println("Property not found, invalid");
	}
	
}
